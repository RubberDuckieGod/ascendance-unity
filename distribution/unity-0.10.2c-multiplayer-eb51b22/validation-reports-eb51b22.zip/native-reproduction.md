# Native dedicated-server acceptance — eb51b22

Source: `eb51b2292cf433a2cbe5dabb4863f1fef993161a`; actual Unity CLI provenance reports `dirty: false`, `outcome: success`; Unity player/server version: `0.10.2c`.

**PASS: 73 plain + 80 pinned-TLS/room-key assertions; zero failures.** Every build file matched the emitted complete SHA-256 manifest. Each run launched fifteen actual Linux Unity server processes using unique temporary XDG data and a random test room/port. All test data was removed; no production server, account or save was used. The native listener binds all interfaces; these test clients connect only to `127.0.0.1`.

This validates the compiled native server with two independent Python protocol clients. Native Unity player rendering/input is a separate acceptance run and is not certified by these results.

| Mechanic | Expected and actual result |
| --- | --- |
| Untouched save/restart | No phantom reward/deck choices; next Hero starts with exactly 3 Actions. |
| Optional pending data | All ten single-field reward/deck records survive an actual process restore. Unknown/incomplete modes remain preserved; this does not claim gameplay support for unknown modes. |
| Legitimate choices | Restored GOLD option adds exactly 25 Gold and clears only its prompt. KEEP leaves Encounter order unchanged and clears deck prompt. |
| Combat | Aldric's 4 Attack against 1 Armor deals exactly 3 Damage per Action; two attacks defeat the 6-Health Raider exactly once. |
| Movement/turns | Revealed connected move completes and costs 1 Action; EndTurn releases ownership; Rowan receives 3 Actions. |
| Consumable | Healing Potion restores 4 Health (4 to 8), consumes one potion and costs one Action. |
| Synchronization | Independent peer observes matching persistent gameplay state after damage, potion and restarted objective progress. |
| Ownership/revisions | Foreign Hero, unjoined socket and concurrent turn commands reject; presence-only revision stays valid; true stale gameplay revision rejects. |
| Idempotence | Repeated attack command never repeats damage/actions/kill; old duplicate returns current state. |
| Idle/reconnect | Both sockets survive more than 36 seconds truly idle; reconnect keeps Hero/session and revokes old socket lease. |
| Process persistence | Actual disk save restores decks/hands/discards, Health, Actions, inventory, statuses, position, turn, round, Gold and enemies; sessions require reconnect proof. |
| Restart replay | Uncertain old-process command rejects; a fresh rescue spends one Action and rescues exactly one Villager. |
| TLS/access control | Missing/wrong room key rejects with no authority data, including nested DTOs; wrong pin rejects before credentials; plaintext cannot obtain a protocol reply. |
| Unauthenticated bounds | Server closes stalled TLS handshake and TLS-without-first-authenticated-request within 7 seconds; authenticated idle remains valid. |

## Reproduced defects fixed

1. The old `9792d16` native build restores absent optional JSON records as blank pending choices, preventing the next Hero's turn after an otherwise untouched save/restart. Restore/clone/application now normalize **only entirely empty** optional records.
2. Retained partial reward data with an absent Mode crashed authority startup in `Append0852SearchChoiceOptions`. The two search-choice readers now decline an empty Mode while preserving the saved record. All ten native preservation cases pass after this fix.

Detailed expected/actual values for every assertion are in `plain.json` and `tls.json`. Native logs are beside them. These assertions inspect gameplay outcomes; socket-open or successful command execution alone is never the passing criterion.

## Reproduce

From the repository root, substitute the complete build and manifest paths:

```sh
python3 -B tools/native_server_acceptance.py \
  --build-dir artifacts/unity-validation/release-eb51b22-20261025T233739Z/LinuxServer \
  --manifest artifacts/unity-validation/release-eb51b22-20261025T233739Z/linux-server-manifest.json \
  --source-revision eb51b2292cf433a2cbe5dabb4863f1fef993161a \
  --output /tmp/ascendance-native-plain.json
```

For TLS, also set `ASCENDANCE_TLS_PFX_PATH` and `ASCENDANCE_TLS_PFX_PASSWORD_FILE`, then pass `--tls-cert-sha256` and `--access-key-file`. Use an isolated certificate with IP SAN `127.0.0.1`, valid serverAuth purpose, and private test credential files. The harness accepts no remote-host or existing-save argument and sends no room credentials before verifying the certificate pin.
