# Final native Unity client acceptance

Runtime source: `eb51b2292cf433a2cbe5dabb4863f1fef993161a`. Both native binaries were built with Unity 6000.6.5f1 from clean source. Complete CLI provenance lives beside the build outputs.

77 expected-versus-actual checks passed, 0 failed. `results.json` contains the detailed assertion record. `visual-review.json` records the actual image review and scope. Both PNGs show the real two-player desktop.

| Mechanic | Expected | Actual |
|---|---|---|
| Native processes | Dedicated server plus two separate graphical clients | Three distinct process IDs; real HUDs and authoritative avatars |
| TLS security | Certificate pin and room invitation required | Correct inputs connect; native wrong-pin/wrong-invitation attempts reject before claiming players |
| Turn start | Three Actions; another Hero cannot start concurrently | Three granted; concurrent turn returns RULE_REJECTED |
| Potion | Ally Health 4→8, actor Actions 3→2, potion 1→0 | Exact values in both replicas |
| Basic attacks | 4 Attack − 1 Armor = 3 Damage each, 1 Action each | Raider Health 6→3→0; actor Actions 2→1→0 |
| Turn transition | Both replicas observe EndTurn before the next Hero starts | Committed gameplay revision observed by both; Rowan starts with 3 Actions |
| Movement | 1 Action per committed adjacent move | Rowan Actions 3→2, synchronized; after server restart 2→1 exactly once |
| Player restart | Retain own Hero claim and canonical state | Same Player ID and ownership; exact gameplay restored in a new process |
| Background play | More than 35 seconds connected, with fresh observations and advancing main loops | 36.0004 seconds; Aldric +78 frames, Rowan +80 frames; fresh observations |
| Camera input | No drift when unfocused, or focused with the pointer outside its window | Actual X focus and Unity focus agree; both cameras drift 0.0 world units |
| Server persistence | Save state survives an actual native process restart | Saved Rowan 2 Actions restored; new server identity accepted; reconnect and subsequent move work |
| Rendered world | Visible terrain and Hero models after idle/restart | Human review of both PNG windows; 186/182 visible world renderers, 45 visible Hero renderers each; actual Hero body projects inside the viewport |

Only synthetic local data was used. Every player, server, and private X server stopped cleanly. The normal Windows and dedicated-server assemblies exclude the development test driver.

Audio output is untested: this host reports native FMOD no-device startup errors before managed gameplay log capture. Windows runtime execution, full visual UX, all card/mechanic coverage, and the public DigitalOcean connection remain outside this suite.
